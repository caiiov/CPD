#include <iostream>
#include <fstream>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>
#include <sstream>
#include <algorithm>
#include <stack>
#include <queue>
#include <iomanip> // Para definir precisão na saída
#include <pthread.h>
#include <mutex>
#include <json/json.h> // Inclusão do JsonCpp
#include <random>
#include <cmath> // Para std::ceil
#include <chrono> // Para medir tempo de execução
#include <sys/resource.h> // Para getrusage
#include <sys/time.h> // Para getrusage

// Estrutura para armazenar informações de um componente
struct ComponentInfo {
    size_t numeroNos;
    size_t numeroArestas;
};

// Estrutura para passar argumentos para as threads de clustering e triângulos
struct ThreadArgs {
    int thread_id;
    int num_threads;
    // Referências para dados compartilhados
    const std::vector<std::vector<int>>* adjList_undirected;
    double somaClustering; // Variável local para cada thread
    size_t totalTriangulos; // Variável local para cada thread
    size_t totalTrios; // Variável local para cada thread
};

// Função para calcular o coeficiente de agrupamento médio (paralela)
void* calcularClustering(void* args) {
    ThreadArgs* threadArgs = static_cast<ThreadArgs*>(args);
    int thread_id = threadArgs->thread_id;
    int num_threads = threadArgs->num_threads;
    const std::vector<std::vector<int>> &adjList = *(threadArgs->adjList_undirected);
    double local_somaClustering = 0.0;

    size_t numeroNosTotal = adjList.size();
    for (size_t i = thread_id; i < numeroNosTotal; i += num_threads) {
        size_t grau = adjList[i].size();

        size_t totalPossiveis = grau * (grau - 1) / 2;
        size_t triangles = 0;
        double C_u = 0.0;

        if (totalPossiveis > 0) {
            for (size_t j = 0; j < adjList[i].size(); ++j) {
                for (size_t k = j + 1; k < adjList[i].size(); ++k) {
                    int neighbor1 = adjList[i][j];
                    int neighbor2 = adjList[i][k];
                    // Como as listas estão ordenadas, usamos binary_search
                    if (std::binary_search(adjList[neighbor1].begin(), adjList[neighbor1].end(), neighbor2)) {
                        triangles++;
                    }
                }
            }
            C_u = static_cast<double>(triangles) / static_cast<double>(totalPossiveis);
        } else {
            C_u = 0.0;
        }

        local_somaClustering += C_u;
    }

    // Atualizar a soma local no objeto ThreadArgs
    threadArgs->somaClustering = local_somaClustering;

    pthread_exit(nullptr);
}

// Função para contar triângulos e trios (paralela)
void* contarTriangulosTrios(void* args) {
    ThreadArgs* threadArgs = static_cast<ThreadArgs*>(args);
    int thread_id = threadArgs->thread_id;
    int num_threads = threadArgs->num_threads;
    const std::vector<std::vector<int>> &adjList = *(threadArgs->adjList_undirected);
    size_t localTriangulos = 0;
    size_t localTrios = 0;

    size_t numeroNosTotal = adjList.size();
    for (size_t i = thread_id; i < numeroNosTotal; i += num_threads) {
        size_t grau = adjList[i].size();

        if (grau < 2) continue;

        // Contar trios locais para o nó atual
        size_t localTriosNode = grau * (grau - 1) / 2;
        localTrios += localTriosNode;

        // Contar triângulos fechados centrados no nó atual
        for (size_t j = 0; j < adjList[i].size(); ++j) {
            for (size_t k = j + 1; k < adjList[i].size(); ++k) {
                int neighbor1 = adjList[i][j];
                int neighbor2 = adjList[i][k];
                if (std::binary_search(adjList[neighbor1].begin(), adjList[neighbor1].end(), neighbor2)) {
                    localTriangulos++;
                }
            }
        }
    }

    // Atualizar os contadores locais no objeto ThreadArgs
    threadArgs->totalTriangulos = localTriangulos;
    threadArgs->totalTrios = localTrios;

    pthread_exit(nullptr);
}

// Estrutura para calcular o diâmetro efetivo
struct EffectiveDiameterArgs {
    int thread_id;
    int num_threads;
    std::vector<int> nodes;
    const std::vector<std::vector<int>>* adjList;
    std::vector<size_t> distance_counts;
    size_t total_paths;
    int local_diameter;
};

// Função de thread para calcular distâncias
void* thread_calcularDistancias_optimized(void* args_void) {
    EffectiveDiameterArgs* eda = static_cast<EffectiveDiameterArgs*>(args_void);
    for (size_t i = eda->thread_id; i < eda->nodes.size(); i += eda->num_threads) {
        // BFS a partir do nó atual
        std::queue<int> fila;
        size_t n = eda->adjList->size();
        std::vector<int> distances(n, -1);
        int start = eda->nodes[i];
        distances[start] = 0;
        fila.push(start);

        while (!fila.empty()) {
            int atual = fila.front();
            fila.pop();

            for (const auto &vizinho : (*eda->adjList)[atual]) {
                if (distances[vizinho] == -1) {
                    distances[vizinho] = distances[atual] + 1;
                    fila.push(vizinho);
                }
            }
        }

        // Atualizar contadores de distância
        for (size_t j = 0; j < distances.size(); ++j) {
            if (distances[j] > 0 && distances[j] <= 1000) { // MAX_DISTANCE = 1000
                eda->distance_counts[distances[j]]++;
            }
            if (distances[j] > eda->local_diameter) {
                eda->local_diameter = distances[j];
            }
            if (distances[j] > 0) {
                eda->total_paths++;
            }
        }
    }
    pthread_exit(nullptr);
}

int main() {
    // Início da medição do tempo total de execução
    auto start_time = std::chrono::high_resolution_clock::now();

    // Estrutura para medir o uso de CPU e memória
    struct rusage usage_start, usage_end;
    getrusage(RUSAGE_SELF, &usage_start);

    std::ifstream arquivo("web-Google.txt");
    if (!arquivo.is_open()) {
        std::cerr << "Erro ao abrir o arquivo 'web-Google.txt'. Verifique se o arquivo existe e o caminho está correto." << std::endl;
        return 1;
    }

    std::unordered_set<long long> nos; // Usando long long para identificar nós numéricos.
    size_t numeroArestasTotal = 0;
    std::vector<std::pair<long long, long long>> arestas_direcionadas; // Lista de arestas direcionadas

    std::string linha;
    while (std::getline(arquivo, linha)) {
        // Ignorar linhas vazias e comentários
        if (linha.empty() || linha[0] == '#') continue;

        std::istringstream iss(linha);
        long long no1, no2;
        if (!(iss >> no1 >> no2)) {
            // Ignorar linhas com formato inválido
            continue;
        }

        // Ignorar loops (auto-arestas)
        if (no1 == no2) continue;

        nos.insert(no1);
        nos.insert(no2);
        arestas_direcionadas.emplace_back(no1, no2);
        numeroArestasTotal++;
    }

    arquivo.close();

    size_t numeroNosTotal = nos.size();

    // Mapeamento de nós para índices
    std::unordered_map<long long, int> mapaNos;
    int indice = 0;
    for (const auto &no : nos) {
        mapaNos[no] = indice++;
    }

    // Construção das listas de adjacência
    // Para WCC e Coeficiente de Agrupamento (não direcionado)
    std::vector<std::vector<int>> adjList_undirected(numeroNosTotal, std::vector<int>());
    // Para SCC (direcionado)
    std::vector<std::vector<int>> adjList_direcionado(numeroNosTotal, std::vector<int>());
    // Para Grafo Transposto (necessário para Kosaraju)
    std::vector<std::vector<int>> adjList_transposto(numeroNosTotal, std::vector<int>());

    // Preencher as listas de adjacência
    for (const auto &aresta : arestas_direcionadas) {
        int idxU = mapaNos[aresta.first];
        int idxV = mapaNos[aresta.second];
        // Para WCC e Coeficiente de Agrupamento
        adjList_undirected[idxU].push_back(idxV);
        adjList_undirected[idxV].push_back(idxU);
        // Para SCC
        adjList_direcionado[idxU].push_back(idxV);
        // Para Grafo Transposto
        adjList_transposto[idxV].push_back(idxU);
    }

    // -------------------
    // Remover Duplicatas e Auto-Arestas nas Listas de Adjacência Não Direcionadas
    // -------------------
    for (size_t i = 0; i < numeroNosTotal; ++i) {
        // Ordenar a lista de adjacência
        std::sort(adjList_undirected[i].begin(), adjList_undirected[i].end());

        // Remover duplicatas
        adjList_undirected[i].erase(std::unique(adjList_undirected[i].begin(), adjList_undirected[i].end()), adjList_undirected[i].end());

        // Remover auto-arestas (nós conectados a si mesmos)
        adjList_undirected[i].erase(std::remove(adjList_undirected[i].begin(), adjList_undirected[i].end(), i), adjList_undirected[i].end());
    }

    // -------------------
    // Cálculo do Maior WCC
    // -------------------
    std::vector<bool> visitado_wcc(numeroNosTotal, false);
    ComponentInfo maiorWCC = {0, 0};
    std::vector<int> maiorWCC_nodes; // Armazenar os nós da maior WCC

    // Função lambda para realizar DFS iterativo para WCC
    auto dfs_iterativo_wcc = [&](int start_node, std::vector<int> &component_nodes) -> ComponentInfo {
        ComponentInfo wcc = {0, 0};
        std::stack<int> pilha;
        pilha.push(start_node);
        visitado_wcc[start_node] = true;
        component_nodes.push_back(start_node);

        while (!pilha.empty()) {
            int node = pilha.top();
            pilha.pop();
            wcc.numeroNos++;

            for (const auto &neighbor : adjList_undirected[node]) {
                wcc.numeroArestas++;
                if (!visitado_wcc[neighbor]) {
                    visitado_wcc[neighbor] = true;
                    pilha.push(neighbor);
                    component_nodes.push_back(neighbor);
                }
            }
        }

        // Cada aresta é contada duas vezes em um grafo não direcionado
        wcc.numeroArestas /= 2;

        return wcc;
    };

    for (int i = 0; i < numeroNosTotal; ++i) {
        if (!visitado_wcc[i]) {
            std::vector<int> current_component_nodes;
            ComponentInfo currentWCC = dfs_iterativo_wcc(i, current_component_nodes);
            if (currentWCC.numeroNos > maiorWCC.numeroNos) {
                maiorWCC = currentWCC;
                maiorWCC_nodes = current_component_nodes;
            }
        }
    }

    // -------------------
    // Cálculo do Maior SCC usando Kosaraju Otimizado
    // -------------------

    // Passo 1: Ordem de finalização usando DFS no grafo direcionado (Iterativo)
    std::vector<bool> visitado_kosaraju(numeroNosTotal, false);
    std::vector<int> ordem_finalizacao;

    // Função lambda para realizar DFS iterativo no grafo direcionado
    auto dfs_iterativo_kosaraju = [&](int start_node, std::vector<int> &ordem) {
        std::stack<std::pair<int, bool>> pilha; // Pair: (node, is_processed)
        pilha.emplace(start_node, false);

        while (!pilha.empty()) {
            auto [node, is_processed] = pilha.top();
            pilha.pop();

            if (is_processed) {
                ordem.push_back(node);
                continue;
            }

            if (visitado_kosaraju[node]) {
                continue;
            }

            visitado_kosaraju[node] = true;
            pilha.emplace(node, true); // Marcar para adicionar à ordem após explorar vizinhos

            for (const auto &neighbor : adjList_direcionado[node]) {
                if (!visitado_kosaraju[neighbor]) {
                    pilha.emplace(neighbor, false);
                }
            }
        }
    };

    for (int i = 0; i < numeroNosTotal; ++i) {
        if (!visitado_kosaraju[i]) {
            dfs_iterativo_kosaraju(i, ordem_finalizacao);
        }
    }

    // Passo 2: DFS no grafo transposto seguindo a ordem de finalização decrescente
    std::fill(visitado_kosaraju.begin(), visitado_kosaraju.end(), false);
    std::vector<int> scc_ids(numeroNosTotal, -1); // ID da SCC para cada nó
    int current_scc_id = 0;
    std::vector<ComponentInfo> scc_infos; // Informações de cada SCC

    // Função lambda para realizar DFS iterativo no grafo transposto e atribuir IDs de SCC
    auto dfs_iterativo_transposto = [&](int start_node, int scc_id, ComponentInfo &scc_info) {
        std::stack<int> pilha;
        pilha.push(start_node);
        visitado_kosaraju[start_node] = true;
        scc_info.numeroNos = 0;

        while (!pilha.empty()) {
            int node = pilha.top();
            pilha.pop();
            scc_info.numeroNos++;
            scc_ids[node] = scc_id;

            for (const auto &neighbor : adjList_transposto[node]) {
                if (!visitado_kosaraju[neighbor]) {
                    visitado_kosaraju[neighbor] = true;
                    pilha.push(neighbor);
                }
            }
        }
    };

    // Iterar na ordem de finalização decrescente
    for (auto it = ordem_finalizacao.rbegin(); it != ordem_finalizacao.rend(); ++it) {
        int node = *it;
        if (!visitado_kosaraju[node]) {
            ComponentInfo scc_info = {0, 0};
            dfs_iterativo_transposto(node, current_scc_id, scc_info);
            scc_infos.push_back(scc_info);
            current_scc_id++;
        }
    }

    // Identificar o maior SCC
    size_t maiorSCC_id = 0;
    size_t maiorSCC_size = 0;
    for (size_t i = 0; i < scc_infos.size(); ++i) {
        if (scc_infos[i].numeroNos > maiorSCC_size) {
            maiorSCC_size = scc_infos[i].numeroNos;
            maiorSCC_id = i;
        }
    }

    // Contar as arestas no maior SCC
    // Abordagem otimizada: Iterar sobre todas as arestas uma única vez
    size_t maiorSCC_arestas = 0;
    for (const auto &aresta : arestas_direcionadas) {
        int idxU = mapaNos[aresta.first];
        int idxV = mapaNos[aresta.second];
        if (scc_ids[idxU] == maiorSCC_id && scc_ids[idxV] == maiorSCC_id) {
            maiorSCC_arestas++;
        }
    }

    // Atualizar o número de arestas do maior SCC
    scc_infos[maiorSCC_id].numeroArestas = maiorSCC_arestas;

    // -------------------
    // Cálculo do Coeficiente de Agrupamento Médio utilizando pthreads - Otimizado
    // -------------------
    double somaClustering = 0.0;
    size_t totalTriangulos = 0;
    size_t totalTrios = 0;

    // Configuração de threading
    const int NUM_THREADS = 8;
    pthread_t threads_ids[NUM_THREADS];
    ThreadArgs threadArgs[NUM_THREADS];

    // Inicializar argumentos para clustering e triângulos
    for (int i = 0; i < NUM_THREADS; ++i) {
        threadArgs[i].thread_id = i;
        threadArgs[i].num_threads = NUM_THREADS;
        threadArgs[i].adjList_undirected = &adjList_undirected;
        threadArgs[i].somaClustering = 0.0;
        threadArgs[i].totalTriangulos = 0;
        threadArgs[i].totalTrios = 0;
    }

    // Criar threads para calcular o coeficiente de agrupamento
    for (int i = 0; i < NUM_THREADS; ++i) {
        if (pthread_create(&threads_ids[i], nullptr, calcularClustering, (void*)&threadArgs[i]) != 0) {
            std::cerr << "Erro ao criar thread " << i << std::endl;
            return 1;
        }
    }

    // Esperar todas as threads terminarem
    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads_ids[i], nullptr);
        somaClustering += threadArgs[i].somaClustering;
    }

    // Cálculo do coeficiente de agrupamento médio
    double averageClusteringCoefficient = somaClustering / static_cast<double>(numeroNosTotal);

    // -------------------
    // Cálculo do Número Total de Triângulos Fechados e Trios Conectados utilizando pthreads - Otimizado
    // -------------------
    // Reiniciar argumentos para triângulos e trios
    for (int i = 0; i < NUM_THREADS; ++i) {
        threadArgs[i].totalTriangulos = 0;
        threadArgs[i].totalTrios = 0;
    }

    // Criar threads para contar triângulos e trios
    for (int i = 0; i < NUM_THREADS; ++i) {
        if (pthread_create(&threads_ids[i], nullptr, contarTriangulosTrios, (void*)&threadArgs[i]) != 0) {
            std::cerr << "Erro ao criar thread " << i << std::endl;
            return 1;
        }
    }

    // Esperar todas as threads terminarem
    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads_ids[i], nullptr);
        totalTriangulos += threadArgs[i].totalTriangulos;
        totalTrios += threadArgs[i].totalTrios;
    }

    // Cada triângulo foi contado três vezes (uma vez para cada nó que o compõe)
    totalTriangulos /= 3;

    // Calcular a Fração de Triângulos Fechados
    double fractionClosedTriangles = 0.0;
    if (totalTrios > 0) {
        fractionClosedTriangles = static_cast<double>(totalTriangulos * 3) / static_cast<double>(totalTrios);
    }

    // -------------------
    // Cálculo do Diâmetro e do Diâmetro Efetivo (90º Percentil) - Otimizado
    // -------------------
    std::vector<int> nodes_in_largest_wcc = maiorWCC_nodes;

    // Definir o número de nós para BFS (exemplo: 1000)
    const size_t NUM_BFS = 1000;

    // Selecionar aleatoriamente 1000 nós da maior WCC sem usar std::find
    std::vector<int> bfs_nodes;
    if (nodes_in_largest_wcc.size() > NUM_BFS) {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::shuffle(nodes_in_largest_wcc.begin(), nodes_in_largest_wcc.end(), gen);
        bfs_nodes.assign(nodes_in_largest_wcc.begin(), nodes_in_largest_wcc.begin() + NUM_BFS);
    } else {
        bfs_nodes = nodes_in_largest_wcc;
    }

    // Atualizar a lista de nós para BFS
    nodes_in_largest_wcc = bfs_nodes;

    // Variáveis para armazenar os comprimentos dos caminhos
    const int MAX_DISTANCE = 1000;
    std::vector<size_t> distance_counts(MAX_DISTANCE + 1, 0);
    size_t total_paths = 0;
    int diameter = 0;

    // Estrutura para armazenar argumentos das threads de diâmetro
    EffectiveDiameterArgs eda_args[NUM_THREADS];
    pthread_t diameter_threads_ids[NUM_THREADS];

    // Inicializar argumentos para threads de diâmetro
    for (int i = 0; i < NUM_THREADS; ++i) {
        eda_args[i].thread_id = i;
        eda_args[i].num_threads = NUM_THREADS;
        eda_args[i].nodes = nodes_in_largest_wcc;
        eda_args[i].adjList = &adjList_undirected;
        eda_args[i].distance_counts.assign(MAX_DISTANCE + 1, 0);
        eda_args[i].total_paths = 0;
        eda_args[i].local_diameter = 0;
    }

    // Criar threads para calcular distâncias
    for (int i = 0; i < NUM_THREADS; ++i) {
        if (pthread_create(&diameter_threads_ids[i], nullptr, thread_calcularDistancias_optimized, (void*)&eda_args[i]) != 0) {
            std::cerr << "Erro ao criar thread de diâmetro " << i << std::endl;
            return 1;
        }
    }

    // Esperar todas as threads terminarem
    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(diameter_threads_ids[i], nullptr);
    }

    // Agregar resultados das threads
    for (int i = 0; i < NUM_THREADS; ++i) {
        for (size_t d = 1; d <= MAX_DISTANCE; ++d) { // Alterado para size_t
            distance_counts[d] += eda_args[i].distance_counts[d];
        }
        if (eda_args[i].local_diameter > diameter) {
            diameter = eda_args[i].local_diameter;
        }
        total_paths += eda_args[i].total_paths;
    }

    // Calcular o percentil de 90% com correções
    size_t target = static_cast<size_t>(std::ceil(0.9 * static_cast<double>(total_paths)));
    size_t cumulative_count = 0;
    int effective_diameter = 0;

    for (size_t d = 1; d <= MAX_DISTANCE; ++d) { // Alterado para size_t
        cumulative_count += distance_counts[d];
        if (cumulative_count >= target) {
            effective_diameter = static_cast<int>(d); // Converter de size_t para int
            break;
        }
    }

    // Verificar se o effective_diameter foi definido
    if (effective_diameter == 0) {
        effective_diameter = diameter;
    }

    // -------------------
    // Medir o uso de CPU e memória após a execução principal
    // -------------------
    getrusage(RUSAGE_SELF, &usage_end);

    // Calcular o tempo de CPU ocupado (tempo de usuário + tempo de sistema)
    double cpu_time_user = (usage_end.ru_utime.tv_sec - usage_start.ru_utime.tv_sec) +
                           (usage_end.ru_utime.tv_usec - usage_start.ru_utime.tv_usec) / 1e6;
    double cpu_time_system = (usage_end.ru_stime.tv_sec - usage_start.ru_stime.tv_sec) +
                             (usage_end.ru_stime.tv_usec - usage_start.ru_stime.tv_usec) / 1e6;
    double cpu_time_total = cpu_time_user + cpu_time_system;

    // Calcular o uso de memória (max RSS em kilobytes)
    long max_rss = usage_end.ru_maxrss; // Em kilobytes

    // Fim da medição do tempo total de execução
    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed_seconds = end_time - start_time;

    // -------------------
    // Montagem do JSON utilizando JsonCpp
    // -------------------
    // Calcular fração de total de nós e arestas para WCC e SCC
    double fraction_nodes_wcc = static_cast<double>(maiorWCC.numeroNos) / static_cast<double>(numeroNosTotal);
    double fraction_edges_wcc = static_cast<double>(maiorWCC.numeroArestas) / static_cast<double>(numeroArestasTotal);
    double fraction_nodes_scc = static_cast<double>(scc_infos[maiorSCC_id].numeroNos) / static_cast<double>(numeroNosTotal);
    double fraction_edges_scc = static_cast<double>(scc_infos[maiorSCC_id].numeroArestas) / static_cast<double>(numeroArestasTotal);

    // Montar o JSON usando JsonCpp
    Json::Value root;
    root["graph_metrics"]["nodes"] = static_cast<Json::UInt64>(numeroNosTotal);
    root["graph_metrics"]["edges"] = static_cast<Json::UInt64>(numeroArestasTotal);

    // Maior WCC
    root["graph_metrics"]["largest_wcc"]["nodes"] = static_cast<Json::UInt64>(maiorWCC.numeroNos);
    root["graph_metrics"]["largest_wcc"]["fraction_of_total_nodes"] = fraction_nodes_wcc;
    root["graph_metrics"]["largest_wcc"]["edges"] = static_cast<Json::UInt64>(maiorWCC.numeroArestas);
    root["graph_metrics"]["largest_wcc"]["fraction_of_total_edges"] = fraction_edges_wcc;

    // Maior SCC
    root["graph_metrics"]["largest_scc"]["nodes"] = static_cast<Json::UInt64>(scc_infos[maiorSCC_id].numeroNos);
    root["graph_metrics"]["largest_scc"]["fraction_of_total_nodes"] = fraction_nodes_scc;
    root["graph_metrics"]["largest_scc"]["edges"] = static_cast<Json::UInt64>(scc_infos[maiorSCC_id].numeroArestas);
    root["graph_metrics"]["largest_scc"]["fraction_of_total_edges"] = fraction_edges_scc;

    // Coeficiente de Agrupamento Médio
    root["graph_metrics"]["average_clustering_coefficient"] = averageClusteringCoefficient;

    // Triângulos e Trios
    root["graph_metrics"]["triangles"] = static_cast<Json::UInt64>(totalTriangulos);
    root["graph_metrics"]["fraction_of_closed_triangles"] = fractionClosedTriangles;

    // Diâmetro e Diâmetro Efetivo
    root["graph_metrics"]["diameter"] = diameter;
    root["graph_metrics"]["effective_diameter_90_percentile"] = effective_diameter;

    // -------------------
    // Adicionar Metricas de Desempenho ao JSON
    // -------------------
    root["performance_metrics"]["execution_time_seconds"] = elapsed_seconds.count();
    root["performance_metrics"]["cpu_time_user_seconds"] = cpu_time_user;
    root["performance_metrics"]["cpu_time_system_seconds"] = cpu_time_system;
    root["performance_metrics"]["cpu_time_total_seconds"] = cpu_time_total;
    root["performance_metrics"]["memory_usage_kb"] = static_cast<Json::Int64>(max_rss);

    // Configurar o escritor JSON
    Json::StreamWriterBuilder writerBuilder;
    writerBuilder["indentation"] = "  "; // Para formatação bonita

    // Escrever o JSON para uma string
    std::string jsonOutput = Json::writeString(writerBuilder, root);

    // Exibir o JSON
    std::cout << jsonOutput << std::endl;

    return 0;
}
