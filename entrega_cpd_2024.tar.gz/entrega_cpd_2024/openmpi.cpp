#include <iostream>
#include <fstream>
#include <string>
#include <unordered_set>
#include <unordered_map>
#include <vector>
#include <sstream>
#include <algorithm>
#include <stack>
#include <queue>
#include <iomanip> // Para definir precisão na saída
#include <json/json.h> // Inclusão do JsonCpp
#include <random>
#include <cmath> // Para std::ceil
#include <sys/resource.h> // Para getrusage
#include <sys/time.h> // Para gettimeofday
#include <unistd.h> // Para read
#include <chrono> // Para medição de tempo
#include <mpi.h> // Inclusão do OpenMPI
#include <omp.h> // Inclusão do OpenMP

// Estrutura para armazenar informações de um componente
struct ComponentInfo {
    size_t numeroNos;
    size_t numeroArestas;
};

// Função para obter o uso de memória residente em KB
size_t getCurrentRSS() {
    std::ifstream status_file("/proc/self/status");
    std::string line;
    size_t rss = 0;
    while (std::getline(status_file, line)) {
        if (line.substr(0, 6) == "VmRSS:") {
            std::istringstream iss(line);
            std::string key;
            size_t value;
            std::string unit;
            iss >> key >> value >> unit;
            rss = value; // em KB
            break;
        }
    }
    return rss;
}

// Função para obter o tempo de CPU (usuário + sistema) em segundos
double getCPUTime() {
    struct rusage usage;
    getrusage(RUSAGE_SELF, &usage);
    double user_time = usage.ru_utime.tv_sec + usage.ru_utime.tv_usec / 1e6;
    double sys_time = usage.ru_stime.tv_sec + usage.ru_stime.tv_usec / 1e6;
    return user_time + sys_time;
}

// Função para realizar BFS e contar distâncias
void bfs_and_count(int start_node, const std::vector<std::vector<int>> &adjList_undirected,
                   std::vector<size_t> &local_distance_counts, size_t &local_total_paths, int &local_diameter) {
    std::queue<int> fila;
    size_t n = adjList_undirected.size();
    std::vector<int> distances(n, -1);
    distances[start_node] = 0;
    fila.push(start_node);

    while (!fila.empty()) {
        int atual = fila.front();
        fila.pop();

        for (const auto &vizinho : adjList_undirected[atual]) {
            if (distances[vizinho] == -1) {
                distances[vizinho] = distances[atual] + 1;
                fila.push(vizinho);
            }
        }
    }

    // Atualizar contadores de distância
    for (size_t j = 0; j < distances.size(); ++j) {
        if (distances[j] > 0 && distances[j] <= 1000) { // MAX_DISTANCE = 1000
            local_distance_counts[distances[j]]++;
        }
        if (distances[j] > local_diameter) {
            local_diameter = distances[j];
        }
        if (distances[j] > 0) {
            local_total_paths++;
        }
    }
}

int main(int argc, char* argv[]) {
    // Inicialização do MPI
    MPI_Init(&argc, &argv);

    int world_rank;
    int world_size;

    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    // Início da medição de tempo apenas no processo raiz
    std::chrono::steady_clock::time_point start_time;
    if (world_rank == 0) {
        start_time = std::chrono::steady_clock::now();
    }

    // Variáveis para armazenar o grafo
    std::unordered_set<long long> nos; // Usando long long para identificar nós numéricos.
    size_t numeroArestasTotal = 0;
    std::vector<std::pair<long long, long long>> arestas_direcionadas; // Lista de arestas direcionadas

    // Processo raiz lê o arquivo e constrói as listas de adjacência
    std::vector<std::vector<int>> adjList_undirected;
    std::vector<std::vector<int>> adjList_direcionado;
    std::vector<std::vector<int>> adjList_transposto;

    if (world_rank == 0) {
        std::ifstream arquivo("web-Google.txt");
        if (!arquivo.is_open()) {
            std::cerr << "Erro ao abrir o arquivo 'web-Google.txt'. Verifique se o arquivo existe e o caminho está correto." << std::endl;
            MPI_Abort(MPI_COMM_WORLD, 1);
        }

        std::string linha;
        while (std::getline(arquivo, linha)) {
            // Ignorar linhas vazias e comentários
            if (linha.empty() || linha[0] == '#') continue;

            std::istringstream iss(linha);
            long long no1, no2;
            if (!(iss >> no1 >> no2)) {
                // Ignorar linhas com formato inválido
                continue;
            }

            // Ignorar loops (auto-arestas)
            if (no1 == no2) continue;

            nos.insert(no1);
            nos.insert(no2);
            arestas_direcionadas.emplace_back(no1, no2);
            numeroArestasTotal++;
        }

        arquivo.close();

        size_t numeroNosTotal = nos.size();

        // Mapeamento de nós para índices
        std::unordered_map<long long, int> mapaNos;
        int indice = 0;
        for (const auto &no : nos) {
            mapaNos[no] = indice++;
        }

        // Construção das listas de adjacência
        // Para WCC e Coeficiente de Agrupamento (não direcionado)
        adjList_undirected.resize(numeroNosTotal, std::vector<int>());
        // Para SCC (direcionado)
        adjList_direcionado.resize(numeroNosTotal, std::vector<int>());
        // Para Grafo Transposto (necessário para Kosaraju)
        adjList_transposto.resize(numeroNosTotal, std::vector<int>());

        // Preencher as listas de adjacência
        for (const auto &aresta : arestas_direcionadas) {
            int idxU = mapaNos[aresta.first];
            int idxV = mapaNos[aresta.second];
            // Para WCC e Coeficiente de Agrupamento
            adjList_undirected[idxU].push_back(idxV);
            adjList_undirected[idxV].push_back(idxU);
            // Para SCC
            adjList_direcionado[idxU].push_back(idxV);
            // Para Grafo Transposto
            adjList_transposto[idxV].push_back(idxU);
        }

        // Remover Duplicatas e Auto-Arestas nas Listas de Adjacência Não Direcionadas
        #pragma omp parallel for schedule(dynamic)
        for (size_t i = 0; i < adjList_undirected.size(); ++i) {
            // Ordenar a lista de adjacência
            std::sort(adjList_undirected[i].begin(), adjList_undirected[i].end());

            // Remover duplicatas
            adjList_undirected[i].erase(std::unique(adjList_undirected[i].begin(), adjList_undirected[i].end()), adjList_undirected[i].end());

            // Remover auto-arestas (nós conectados a si mesmos)
            adjList_undirected[i].erase(std::remove(adjList_undirected[i].begin(), adjList_undirected[i].end(), i), adjList_undirected[i].end());
        }

        // Serializar as listas de adjacência para enviar aos outros processos
        // Primeiro, enviar o número de nós
        for (int dest = 1; dest < world_size; ++dest) {
            long long numeroNosTotal_ll = adjList_undirected.size();
            MPI_Send(&numeroNosTotal_ll, 1, MPI_LONG_LONG, dest, 0, MPI_COMM_WORLD);
        }

        // Enviar as listas de adjacência
        for (int dest = 1; dest < world_size; ++dest) {
            // Enviar adjList_undirected
            for (size_t i = 0; i < adjList_undirected.size(); ++i) {
                int grau = adjList_undirected[i].size();
                MPI_Send(&grau, 1, MPI_INT, dest, 1, MPI_COMM_WORLD);
                if (grau > 0) {
                    MPI_Send(adjList_undirected[i].data(), grau, MPI_INT, dest, 2, MPI_COMM_WORLD);
                }
            }
        }
    } else {
        // Outros processos recebem o número de nós
        long long numeroNosTotal_ll;
        MPI_Recv(&numeroNosTotal_ll, 1, MPI_LONG_LONG, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        size_t numeroNosTotal = static_cast<size_t>(numeroNosTotal_ll);

        // Inicializar listas de adjacência
        std::vector<std::vector<int>> adjList_undirected_local(numeroNosTotal, std::vector<int>());

        // Receber as listas de adjacência
        for (size_t i = 0; i < numeroNosTotal; ++i) {
            int grau;
            MPI_Recv(&grau, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            if (grau > 0) {
                adjList_undirected_local[i].resize(grau);
                MPI_Recv(adjList_undirected_local[i].data(), grau, MPI_INT, 0, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }

        // Substituir a lista completa pela lista local (se implementado corretamente)
        // Neste exemplo, cada processo tem a lista completa, o que não é ideal para grafos grandes
        // Para melhorar, você deve distribuir apenas uma parte do grafo para cada processo
        // Aqui, continuamos com a lista completa para simplificação
        // Em uma implementação completa, modifique para distribuir os nós de forma eficiente
    }

    // Sincronizar todos os processos
    MPI_Barrier(MPI_COMM_WORLD);

    // Agora, todos os processos possuem adjList_undirected_all
    std::vector<std::vector<int>> adjList_undirected_all;
    if (world_rank == 0) {
        adjList_undirected_all = adjList_undirected;
    } else {
        // Receber as listas de adjacência no processo não raiz
        long long numeroNosTotal_ll;
        MPI_Bcast(&numeroNosTotal_ll, 1, MPI_LONG_LONG, 0, MPI_COMM_WORLD);
        size_t numeroNosTotal = static_cast<size_t>(numeroNosTotal_ll);
        adjList_undirected_all.resize(numeroNosTotal, std::vector<int>());
        for (size_t i = 0; i < numeroNosTotal; ++i) {
            int grau;
            MPI_Recv(&grau, 1, MPI_INT, 0, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            if (grau > 0) {
                adjList_undirected_all[i].resize(grau);
                MPI_Recv(adjList_undirected_all[i].data(), grau, MPI_INT, 0, 2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }
    }

    // -------------------
    // Cálculo do Coeficiente de Agrupamento Médio utilizando OpenMPI e OpenMP
    // -------------------
    double somaClustering = 0.0;
    size_t numeroNosTotal = adjList_undirected_all.size();

    // Paralelizar o cálculo do coeficiente de agrupamento
    #pragma omp parallel for reduction(+:somaClustering) schedule(dynamic)
    for (size_t i = 0; i < adjList_undirected_all.size(); ++i) {
        size_t grau = adjList_undirected_all[i].size();

        size_t totalPossiveis = grau * (grau - 1) / 2;
        size_t triangles = 0;
        double C_u = 0.0;

        if (totalPossiveis > 0) {
            for (size_t j = 0; j < adjList_undirected_all[i].size(); ++j) {
                for (size_t k = j + 1; k < adjList_undirected_all[i].size(); ++k) {
                    int neighbor1 = adjList_undirected_all[i][j];
                    int neighbor2 = adjList_undirected_all[i][k];
                    // Como as listas estão ordenadas, usamos binary_search
                    if (std::binary_search(adjList_undirected_all[neighbor1].begin(), adjList_undirected_all[neighbor1].end(), neighbor2)) {
                        triangles++;
                    }
                }
            }
            C_u = static_cast<double>(triangles) / static_cast<double>(totalPossiveis);
        } else {
            C_u = 0.0;
        }

        somaClustering += C_u;
    }

    // Reduzir os resultados para o processo raiz
    double somaClustering_total = 0.0;
    MPI_Reduce(&somaClustering, &somaClustering_total, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    // -------------------
    // Cálculo do Número Total de Triângulos Fechados e Trios Conectados utilizando OpenMPI e OpenMP
    // -------------------
    size_t totalTriangulos = 0;
    size_t totalTrios = 0;

    // Contagem de triângulos e trios
    #pragma omp parallel for reduction(+:totalTriangulos, totalTrios) schedule(dynamic)
    for (size_t i = 0; i < adjList_undirected_all.size(); ++i) {
        size_t grau = adjList_undirected_all[i].size();

        if (grau < 2) continue;

        // Contar trios locais para o nó atual
        size_t localTriosNode = grau * (grau - 1) / 2;
        totalTrios += localTriosNode;

        // Contar triângulos fechados centrados no nó atual
        size_t localTriangulos = 0;
        for (size_t j = 0; j < adjList_undirected_all[i].size(); ++j) {
            for (size_t k = j + 1; k < adjList_undirected_all[i].size(); ++k) {
                int neighbor1 = adjList_undirected_all[i][j];
                int neighbor2 = adjList_undirected_all[i][k];
                if (std::binary_search(adjList_undirected_all[neighbor1].begin(), adjList_undirected_all[neighbor1].end(), neighbor2)) {
                    localTriangulos++;
                }
            }
        }
        totalTriangulos += localTriangulos;
    }

    // Reduzir os resultados para o processo raiz
    size_t totalTriangulos_total = 0;
    size_t totalTrios_total = 0;
    MPI_Reduce(&totalTriangulos, &totalTriangulos_total, 1, MPI_UNSIGNED_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&totalTrios, &totalTrios_total, 1, MPI_UNSIGNED_LONG, MPI_SUM, 0, MPI_COMM_WORLD);

    // Cada triângulo foi contado três vezes (uma vez para cada nó que o compõe)
    if (world_rank == 0) {
        totalTriangulos_total /= 3;
    }

    // -------------------
    // Cálculo do Diâmetro Efetivo (90º Percentil) utilizando OpenMPI e OpenMP
    // -------------------
    std::vector<int> nodes_in_largest_wcc;
    if (world_rank == 0) {
        // Identificar a Maior WCC
        // Implementação simplificada: considerar todos os nós conectados (já que listas são não direcionadas)
        // Em uma implementação completa, você deveria implementar o cálculo da maior WCC
        // Aqui, assumimos que todos os nós estão na maior WCC
        nodes_in_largest_wcc.resize(adjList_undirected_all.size());
        for (size_t i = 0; i < adjList_undirected_all.size(); ++i) {
            nodes_in_largest_wcc[i] = i;
        }

        // Selecionar aleatoriamente 1000 nós da maior WCC
        const size_t NUM_BFS = 1000;
        std::vector<int> bfs_nodes;
        if (nodes_in_largest_wcc.size() > NUM_BFS) {
            std::random_device rd;
            std::mt19937 gen(rd());
            std::shuffle(nodes_in_largest_wcc.begin(), nodes_in_largest_wcc.end(), gen);
            bfs_nodes.assign(nodes_in_largest_wcc.begin(), nodes_in_largest_wcc.begin() + NUM_BFS);
        } else {
            bfs_nodes = nodes_in_largest_wcc;
        }
        nodes_in_largest_wcc = bfs_nodes;
    }

    // Broadcast do tamanho da lista de nós para BFS
    size_t bfs_size = nodes_in_largest_wcc.size();
    MPI_Bcast(&bfs_size, 1, MPI_UNSIGNED_LONG, 0, MPI_COMM_WORLD);

    // Distribuir os nós para BFS
    std::vector<int> nodes_bfs(bfs_size);
    if (world_rank == 0) {
        nodes_bfs = nodes_in_largest_wcc;
    }
    MPI_Bcast(nodes_bfs.data(), bfs_size, MPI_INT, 0, MPI_COMM_WORLD);

    // Cada processo calcula suas próprias distâncias
    size_t local_total_paths = 0;
    int local_diameter = 0;
    std::vector<size_t> local_distance_counts(1001, 0); // MAX_DISTANCE = 1000

    // Distribuir os nós para cada processo
    #pragma omp parallel for reduction(+:local_total_paths, local_diameter)
    for (size_t i = world_rank; i < nodes_bfs.size(); i += world_size) {
        bfs_and_count(nodes_bfs[i], adjList_undirected_all, local_distance_counts, local_total_paths, local_diameter);
    }

    // Reduzir os resultados para o processo raiz
    std::vector<size_t> global_distance_counts(1001, 0);
    size_t global_total_paths = 0;
    int global_diameter = 0;

    MPI_Reduce(local_distance_counts.data(), global_distance_counts.data(), 1001, MPI_UNSIGNED_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_total_paths, &global_total_paths, 1, MPI_UNSIGNED_LONG, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&local_diameter, &global_diameter, 1, MPI_INT, MPI_MAX, 0, MPI_COMM_WORLD);

    // Processo raiz calcula o diâmetro efetivo
    int effective_diameter = 0;
    if (world_rank == 0) {
        size_t target = static_cast<size_t>(std::ceil(0.9 * static_cast<double>(global_total_paths)));
        size_t cumulative_count = 0;

        for (size_t d = 1; d <= 1000; ++d) {
            cumulative_count += global_distance_counts[d];
            if (cumulative_count >= target) {
                effective_diameter = static_cast<int>(d);
                break;
            }
        }

        if (effective_diameter == 0) {
            effective_diameter = global_diameter;
        }
    }

    // -------------------
    // Processo raiz prepara e imprime os resultados
    // -------------------
    if (world_rank == 0) {
        // Fim da medição de tempo
        auto end_time = std::chrono::steady_clock::now();
        std::chrono::duration<double> elapsed_seconds = end_time - start_time;
        double wall_clock_time = elapsed_seconds.count(); // em segundos

        // Obter tempo de CPU usado
        double cpu_time = getCPUTime(); // em segundos

        // Obter uso de memória
        size_t memory_usage_kb = getCurrentRSS(); // em KB

        // Calcular fração de nós e arestas
        double fraction_nodes_wcc = 1.0; // Assumido que todos os nós estão na maior WCC
        double fraction_edges_wcc = 1.0; // Assumido que todas as arestas estão na maior WCC
        // Implementar cálculo real da maior SCC se necessário
        double fraction_nodes_scc = 0.0; // Placeholder
        double fraction_edges_scc = 0.0; // Placeholder

        // Preparar o JSON
        Json::Value root;
        root["graph_metrics"]["nodes"] = static_cast<Json::UInt64>(numeroNosTotal);
        root["graph_metrics"]["edges"] = static_cast<Json::UInt64>(numeroArestasTotal);

        // Maior WCC
        root["graph_metrics"]["largest_wcc"]["nodes"] = static_cast<Json::UInt64>(numeroNosTotal);
        root["graph_metrics"]["largest_wcc"]["fraction_of_total_nodes"] = fraction_nodes_wcc;
        root["graph_metrics"]["largest_wcc"]["edges"] = static_cast<Json::UInt64>(numeroArestasTotal);
        root["graph_metrics"]["largest_wcc"]["fraction_of_total_edges"] = fraction_edges_wcc;

        // Maior SCC - Placeholder
        root["graph_metrics"]["largest_scc"]["nodes"] = static_cast<Json::UInt64>(0);
        root["graph_metrics"]["largest_scc"]["fraction_of_total_nodes"] = fraction_nodes_scc;
        root["graph_metrics"]["largest_scc"]["edges"] = static_cast<Json::UInt64>(0);
        root["graph_metrics"]["largest_scc"]["fraction_of_total_edges"] = fraction_edges_scc;

        // Coeficiente de Agrupamento Médio
        double averageClusteringCoefficient = somaClustering_total / static_cast<double>(numeroNosTotal);
        root["graph_metrics"]["average_clustering_coefficient"] = averageClusteringCoefficient;

        // Triângulos e Trios
        root["graph_metrics"]["triangles"] = static_cast<Json::UInt64>(totalTriangulos_total);
        double fractionClosedTriangles = 0.0;
        if (totalTrios_total > 0) {
            fractionClosedTriangles = static_cast<double>(totalTriangulos_total * 3) / static_cast<double>(totalTrios_total);
        }
        root["graph_metrics"]["fraction_of_closed_triangles"] = fractionClosedTriangles;

        // Diâmetro e Diâmetro Efetivo
        root["graph_metrics"]["diameter"] = static_cast<Json::Int64>(global_diameter);
        root["graph_metrics"]["effective_diameter_90_percentile"] = static_cast<Json::Int64>(effective_diameter);

        // Configurar o escritor JSON
        Json::StreamWriterBuilder writerBuilder;
        writerBuilder["indentation"] = "  "; // Para formatação bonita

        // Escrever o JSON para uma string
        std::string jsonOutput = Json::writeString(writerBuilder, root);

        // Impressão dos Resultados no Console
        std::cout << "===================== Resultados do Grafo =====================" << std::endl;
        std::cout << jsonOutput << std::endl;
        std::cout << "===============================================================" << std::endl;
        std::cout << std::endl;

        // Impressão dos Dados de CPU e Memória
        std::cout << "===================== Dados de Desempenho =====================" << std::endl;
        std::cout << "Tempo Total de Execução (Wall-Clock Time): " << std::fixed << std::setprecision(6) << wall_clock_time << " segundos" << std::endl;
        std::cout << "Tempo Total de CPU Ocupado: " << std::fixed << std::setprecision(6) << cpu_time << " segundos" << std::endl;
        std::cout << "Consumo de Memória: " << memory_usage_kb / 1024.0 << " MB" << std::endl;
        std::cout << "===============================================================" << std::endl;
    }

    // Finalização do MPI
    MPI_Finalize();

    return 0;
}
